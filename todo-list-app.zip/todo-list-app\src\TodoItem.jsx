import React from 'react';

function TodoItem({ todo, toggleTodo, deleteTodo }) {
  return (
    <li className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      <span onClick={() => toggleTodo(todo.id)}>{todo.text}</span>
      <button className="delete-btn" onClick={() => deleteTodo(todo.id)}>Eliminar</button>
    </li>
  );
}
export default TodoItem;
