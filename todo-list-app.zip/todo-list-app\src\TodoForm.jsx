import React, { useState } from 'react';

function TodoForm({ addTodo }) {
  const [input, setInput] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    addTodo(input.trim());
    setInput('');
  };
  return (
    <form onSubmit={handleSubmit} className="todo-form">
      <input type="text" placeholder="Escribe una nueva tarea..." value={input} onChange={(e) => setInput(e.target.value)} />
      <button type="submit">Añadir</button>
    </form>
  );
}
export default TodoForm;
